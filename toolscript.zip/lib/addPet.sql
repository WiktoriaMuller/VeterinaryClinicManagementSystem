INSERT INTO pets (name, species, breed, birth_date)
VALUES ({{ nameInput.value }}, {{ speciesSelect.value }}, {{ breedInput.value }}, {{ birthdateInput.value }});